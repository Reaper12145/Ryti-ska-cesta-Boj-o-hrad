Hlavní děj

Vysoko v horách leží tajemný hrad, který byl kdysi sídlem mocného krále. Jeho poddaní mu sloužili s oddaností, ale když se na obzoru objevil drak, jejich životy se změnily. Drak vybíral výpalné a ničil vesnice, a tak král vyslal své rytíře, aby zvíře porazili.

Rytíři se vydali na nebezpečnou cestu, aby se utkali s drakem. Cestou se však setkali s podivnými zjeveními a museli čelit nebezpečím, která na ně číhala v podzemí.

Po mnoha překážkách se rytíři dostali k drakovi a začala se bitva. Drak byl obrovský a silný, ale rytíři nevzdávali. Boj trval celou noc a nakonec se rytířům podařilo draka zabít.

Král byl rytířům velmi vděčný a slíbil, že na oplátku ochrání své poddané před dalšími nebezpečími. Avšak podzemí plné záhad a magie se ukázalo být větší hrozbou, než si kdy král dokázal představit.

Podzemní bytosti se vzbouřily proti království a začaly útočit na obyvatele. Král opět vyslal rytíře, aby situaci řešili. Rytíři se snažili najít způsob, jak porazit podzemní bytosti, ale bez úspěchu.

Nakonec objevili kouzelníka, který měl mocné kouzlo, které by podzemní bytosti zahnalo zpět do podzemí. Rytíři se s kouzelníkem spojili a společně dokázali království ochránit před záhadnými útoky.

Král byl rytířům velmi vděčný za jejich hrdinství a tak jim daroval hrad, aby se o něj mohli starat. Rytíři se stali ochránci hradu a poddaných a celé království žilo dlouho v míru a bezpečí.

Špatné volby 

Špatná volba: Rytíři se rozhodnou nejít na cestu za drakem a nechat ho terorizovat obyvatele. To by způsobilo, že vesnice by se stala zničenou a lidé by museli utíkat.
Špatná volba: Rytíři jsou příliš zbrklí v boji s drakem a neplánují svůj útok. To by mohlo způsobit jejich porážku a možná i smrt.
Špatná volba: Rytíři ignorují podivné zjevení a nevěnují mu pozornost. To by mohlo vést k nebezpečí, které by se mohlo stát ještě větším.
Špatná volba: Rytíři nevěnují pozornost kouzelníkovi a nevěří, že by mohl pomoci s porážkou podzemních bytostí. To by znamenalo, že by se podzemní bytosti mohly stát nebezpečím pro celé království.
Špatná volba: Rytíři se rozhodnou zradit krále a ujmout se sami vlády nad královstvím. To by mohlo vést k válce a neklidu v království.





Přídavky
Pokémoni: 
Když se rytíři dostanou na hrad, zjistí, že pod jeho zdmi se skrývá tajemné podzemí plné magie a nebezpečí. Při průzkumu objeví skupinu trenérů Pokémonů, kteří se snaží chránit království před nebezpečnými divokými Pokémony, kteří se zde vyskytují. 
Rytíři se rozhodnou pomoci a vstoupí do podzemí s pokémony u svého boku. Společně bojují proti nebezpečným Pokémonům, kteří ohrožují poddané a království jako celek. 
Během svých dobrodružství se setkají s různými druhy Pokémonů a budou muset vyvinout své strategické dovednosti, aby je mohli úspěšně porazit. Kromě toho zjistí, že jedna z významných postav podzemí ovládá kouzla a může jim pomoci v boji. 
S její pomocí objeví tajemství, které může být klíčem k porážce nejnebezpečnějšího Pokémona v podzemí, který se snaží dostat na povrch a ohrozit celé království. 
Rytíři a jejich Pokémoni se proto musí spojit s dalšími trenéry Pokémonů a společně se vydat na nebezpečnou cestu k temnému jádru podzemí, kde musí čelit poslední výzvě a porazit nejnebezpečnějšího Pokémona v boji na život a na smrt.



Postavy

vypravěč(začátek)
rytíři (5)
feudál (1)
král (1)
pokémoni (různé druhy)
drak (5 hlav)
kouzelníci (armáda)
veliký kouzelník (mocná kouzla)



Vypravěč:Vysoko v horách leží tajemný hrad, který byl kdysi sídlem mocného krále. Jeho poddaní mu sloužili s oddaností, ale když se na obzoru objevil drak, jejich životy se změnily. Drak vybíral výpalné a ničil vesnice, a tak král vyslal své rytíře, aby zvíře porazili.

Kral: Milý feudále. Vy víte o tom, že naše království týrá zlý drak. Jste schopen se svými rytíři ho zneškodnit?

Feudál: 1, Ano, my to zvládneme. ( příběh pokračuje)
	2, Ne, to nedokážeme. (království rip)

Král: Jsem rád že vás mám k dispozici. Jestli to zvládnete nemine vás odměna v podobě jakékoliv ženy nebo pokémona z podhradí. Vkládám do vás budoucnost tohoto království.





┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼
███▀▀▀██┼███▀▀▀███┼███▀█▄█▀███┼██▀▀▀
██┼┼┼┼██┼██┼┼┼┼┼██┼██┼┼┼█┼┼┼██┼██┼┼┼
██┼┼┼▄▄▄┼██▄▄▄▄▄██┼██┼┼┼▀┼┼┼██┼██▀▀▀
██┼┼┼┼██┼██┼┼┼┼┼██┼██┼┼┼┼┼┼┼██┼██┼┼┼
███▄▄▄██┼██┼┼┼┼┼██┼██┼┼┼┼┼┼┼██┼██▄▄▄
┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼
███▀▀▀███┼▀███┼┼██▀┼██▀▀▀┼██▀▀▀▀██▄┼
██┼┼┼┼┼██┼┼┼██┼┼██┼┼██┼┼┼┼██┼┼┼┼┼██┼
██┼┼┼┼┼██┼┼┼██┼┼██┼┼██▀▀▀┼██▄▄▄▄▄▀▀┼
██┼┼┼┼┼██┼┼┼██┼┼█▀┼┼██┼┼┼┼██┼┼┼┼┼██┼
███▄▄▄███┼┼┼─▀█▀┼┼─┼██▄▄▄┼██┼┼┼┼┼██▄
┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼██┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼██┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼████▄┼┼┼▄▄▄▄▄▄▄┼┼┼▄████┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼┼▀▀█▄█████████▄█▀▀┼┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼┼┼┼█████████████┼┼┼┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼┼┼┼██▀▀▀███▀▀▀██┼┼┼┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼┼┼┼██┼┼┼███┼┼┼██┼┼┼┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼┼┼┼█████▀▄▀█████┼┼┼┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼┼┼┼┼███████████┼┼┼┼┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼▄▄▄██┼┼█▀█▀█┼┼██▄▄▄┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼▀▀██┼┼┼┼┼┼┼┼┼┼┼██▀▀┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼┼┼▀▀┼┼┼┼┼┼┼┼┼┼┼▀▀┼┼┼┼┼┼┼┼┼┼┼
┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼┼


