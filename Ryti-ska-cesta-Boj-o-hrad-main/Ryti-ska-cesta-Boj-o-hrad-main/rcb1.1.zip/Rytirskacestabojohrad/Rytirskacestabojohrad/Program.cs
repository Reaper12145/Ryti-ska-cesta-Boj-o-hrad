﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Rytirskacestabojohrad
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //postavy
            rytir rytir = new rytir();
            vypravec vypravec = new vypravec();

            kral kral = new kral();
            //děj
            Console.ForegroundColor = ConsoleColor.Green;
            //vypravec.uvod();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            kral.uvod();
            string input = Console.ReadLine();
            try
            {
                if (input.ToLower() == "a")
                {
                    Console.WriteLine("Nabidka přijata");


                }
                else if (input.ToLower() == "n")
                {
                    Console.Clear();
                    Console.WriteLine("Nabidka byla odmitnuta");
                    vypravec.Vypaleni();
                    vypravec.HodKostkou();

                }              
            }
            catch 
            {
                Console.WriteLine("Neplatná volba.");

            }







            //děj
            Console.ForegroundColor = ConsoleColor.Green;
            vypravec.uvod();
            Console.Clear();
            
            Console.ForegroundColor= ConsoleColor.Yellow;
            kral.uvod();


            Console.ReadKey();
        }
    }
}
