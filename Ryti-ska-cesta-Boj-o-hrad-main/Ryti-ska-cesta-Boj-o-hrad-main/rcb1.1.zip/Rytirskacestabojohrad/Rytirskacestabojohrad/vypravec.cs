﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Rytirskacestabojohrad
{
    internal class vypravec:bytost
    {
        public string jmeno = "Vypravěč";
        public override int uvod()
        {

            Console.WriteLine("{0}: Vysoko v horách leží tajemný hrad, který byl kdysi sídlem mocného krále.", jmeno);
            Thread.Sleep(5000);
            Console.WriteLine("{0}: Jeho poddaní mu sloužili s oddaností, ale když se na obzoru objevil drak, jejich životy se změnily.", jmeno);
            Thread.Sleep(5500);
            Console.WriteLine("{0}: Drak vybíral výpalné a ničil vesnice.", jmeno);
            Thread.Sleep(3000);
            return 0;
        }
        public override int Vypaleni()
            {

            Console.WriteLine("Hrozný drak dále tyranizoval hrad a poddané ");
            Thread.Sleep(1000);
            Console.ForegroundColor = ConsoleColor.White;
            return 0;
            }

        public override int HodKostkou()
        {
            Thread.Sleep(2000);
            Console.WriteLine("Hoď si s kostkou pokud ti padne 6 mužeš pokračovat v přiběhu pokud spadne meně hra se vypne");
            Thread.Sleep(1000);
            Console.WriteLine("hodiš zmačknuti klavesy");
            Console.ReadKey();

            Random rand = new Random();
            int randomNumber = rand.Next(1, 7);
            Console.WriteLine("Hodnota kostky: " + randomNumber);
            Thread.Sleep(2000);


            if (randomNumber == 6)
            {
                uvod();
            }
            if (randomNumber < 6)
            {
                Console.Clear();
                Console.WriteLine("Game Over");
                Console.ReadKey();
                Environment.Exit(0);
            }
            if (randomNumber == 2)
            {
                System.Diagnostics.Process.Start("https://www.youtube.com/watch?v=dQw4w9WgXcQ%22");
                Console.Clear();
                Console.WriteLine("Game Over");
                Console.ReadLine();
                Environment.Exit(0);
            }
            return 0;
        }
    }
}
