﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Rytirskacestabojohrad
{
    internal class Program:bytost
    {
        static void Main(string[] args)
        {

            //postavy
            rytir rytir = new rytir();
            vypravec vypravec = new vypravec();
            kral kral = new kral();
            banditi banditi = new banditi();


            //tutorial
            //vypravec.Tutorial();


            //děj 
            //vypravec.uvod();          
            //kral.uvod();

           /* string input = Console.ReadLine();
    
                if (input.ToLower() == "1")
                {
                    Console.Clear();
                    Console.WriteLine("Ano, my to zvládneme.");
                Thread.Sleep(2000);
                    kral.DruhaCast();

                }
                else if (input.ToLower() == "2")
                {
                    Console.Clear();
                    Console.WriteLine("Ne, to nedokážeme.");
                    vypravec.Vypaleni();
                    vypravec.HodKostkou();

                }
                else
                {
                    Console.WriteLine("Neplatná volba.");
                    
                }
            */

            //vypravec.DruhaCast();
            vypravec.TretiCast();
            banditi.TretiCast();

                string input = Console.ReadLine();
    
                if (input.ToLower() == "1")
                {
                    Console.Clear();
                    Console.WriteLine("loupežníci je jednoduše zabili");
                    Thread.Sleep(2000);
                    vypravec.HodKostkou();

                }
                else if (input.ToLower() == "2")
                {
                    Console.Clear();
                    Console.WriteLine("rytíři přemůžou všechny loupežníky");
                   

                }
                else
                {
                Console.WriteLine("Neplatna volba");
                    
                }







            Console.ReadKey();
        }
    }
}
